import {
  siAgentskills,
  siClaude,
  siClaudecode,
  siCursor,
  type SimpleIcon,
} from "simple-icons";
import type { AgentId } from "./catalog.ts";

export type RuntimeBrandId = AgentId | "claude-app" | "chatgpt" | "agent-skills";

export type RuntimeBrandIcon =
  | { viewBox: string; path: string; imageSrc?: never }
  | { viewBox: string; imageSrc: string; path?: never };

export interface RuntimeBrandDefinition {
  id: RuntimeBrandId;
  label: string;
  shortLabel: string;
  /** The mark color chosen for the site's near-black surfaces. */
  colorOnDark: `#${string}`;
  icon: RuntimeBrandIcon;
  sourceUrl: string;
}

function fromSimpleIcon(icon: SimpleIcon): RuntimeBrandIcon {
  return {
    viewBox: "0 0 24 24",
    path: icon.path,
  };
}

/** The central Blossom path from OpenAI's official brand asset. */
const OPENAI_BLOSSOM: RuntimeBrandIcon = {
  viewBox: "146.694 227.042 267.198 264.812",
  path: "M249.176 323.434V298.276C249.176 296.158 249.971 294.569 251.825 293.509L302.406 264.381C309.29 260.409 317.5 258.555 325.973 258.555C357.75 258.555 377.877 283.185 377.877 309.399C377.877 311.253 377.877 313.371 377.611 315.49L325.178 284.771C322.001 282.919 318.822 282.919 315.645 284.771L249.176 323.434ZM367.283 421.415V361.301C367.283 357.592 365.694 354.945 362.516 353.092L296.048 314.43L317.763 301.982C319.617 300.925 321.206 300.925 323.058 301.982L373.639 331.112C388.205 339.586 398.003 357.592 398.003 375.069C398.003 395.195 386.087 413.733 367.283 421.412V421.415ZM233.553 368.452L211.838 355.742C209.986 354.684 209.19 353.095 209.19 350.975V292.718C209.19 264.383 230.905 242.932 260.301 242.932C271.423 242.932 281.748 246.641 290.49 253.26L238.321 283.449C235.146 285.303 233.555 287.951 233.555 291.659V368.455L233.553 368.452ZM280.292 395.462L249.176 377.985V340.913L280.292 323.436L311.407 340.913V377.985L280.292 395.462ZM300.286 475.968C289.163 475.968 278.837 472.259 270.097 465.64L322.264 435.449C325.441 433.597 327.03 430.949 327.03 427.239V350.445L349.011 363.155C350.865 364.213 351.66 365.802 351.66 367.922V426.179C351.66 454.514 329.679 475.965 300.286 475.965V475.968ZM237.525 416.915L186.944 387.785C172.378 379.31 162.582 361.305 162.582 343.827C162.582 323.436 174.763 305.164 193.563 297.485V357.861C193.563 361.571 195.154 364.217 198.33 366.071L264.535 404.467L242.82 416.915C240.967 417.972 239.377 417.972 237.525 416.915ZM234.614 460.343C204.689 460.343 182.71 437.833 182.71 410.028C182.71 407.91 182.976 405.792 183.238 403.672L235.405 433.863C238.582 435.715 241.763 435.715 244.938 433.863L311.407 395.466V420.622C311.407 422.742 310.612 424.331 308.758 425.389L258.179 454.519C251.293 458.491 243.083 460.343 234.611 460.343H234.614ZM300.286 491.854C332.329 491.854 359.073 469.082 365.167 438.892C394.825 431.211 413.892 403.406 413.892 375.073C413.892 356.535 405.948 338.529 391.648 325.552C392.972 319.991 393.766 314.43 393.766 308.87C393.766 271.003 363.048 242.666 327.562 242.666C320.413 242.666 313.528 243.723 306.644 246.109C294.725 234.457 278.307 227.042 260.301 227.042C228.258 227.042 201.513 249.815 195.42 280.004C165.761 287.685 146.694 315.49 146.694 343.824C146.694 362.362 154.638 380.368 168.938 393.344C167.613 398.906 166.819 404.467 166.819 410.027C166.819 447.894 197.538 476.231 233.024 476.231C240.172 476.231 247.058 475.173 253.943 472.788C265.859 484.441 282.278 491.854 300.286 491.854Z",
};

export const RUNTIME_BRANDS = {
  "claude-code": {
    id: "claude-code",
    label: "Claude Code",
    shortLabel: "Claude",
    colorOnDark: "#D97757",
    icon: fromSimpleIcon(siClaudecode),
    sourceUrl: "https://simpleicons.org/?q=claude+code",
  },
  codex: {
    id: "codex",
    label: "Codex",
    shortLabel: "Codex",
    colorOnDark: "#8DA4FF",
    icon: {
      viewBox: "0 0 1024 1024",
      imageSrc: "/brands/codex.png",
    },
    sourceUrl: "https://chatgpt.com/features/codex-get-started/",
  },
  cursor: {
    id: "cursor",
    label: "Cursor",
    shortLabel: "Cursor",
    colorOnDark: "#F7F7F4",
    icon: fromSimpleIcon(siCursor),
    sourceUrl: "https://simpleicons.org/?q=cursor",
  },
  "claude-app": {
    id: "claude-app",
    label: "Claude app",
    shortLabel: "Claude",
    colorOnDark: "#D97757",
    icon: fromSimpleIcon(siClaude),
    sourceUrl: "https://simpleicons.org/?q=claude",
  },
  chatgpt: {
    id: "chatgpt",
    label: "ChatGPT",
    shortLabel: "ChatGPT",
    colorOnDark: "#F7F7F4",
    icon: OPENAI_BLOSSOM,
    sourceUrl: "https://images.ctfassets.net/kftzwdyauwt9/3hUGLn3ypllZ0oa01qOYVq/28e8188e6f11b84c3e876569d492734f/Blossom_Light.svg",
  },
  "agent-skills": {
    id: "agent-skills",
    label: "Agent Skills",
    shortLabel: "Skills",
    colorOnDark: "#F7F7F4",
    icon: fromSimpleIcon(siAgentskills),
    sourceUrl: "https://simpleicons.org/?q=agent+skills",
  },
} as const satisfies Record<RuntimeBrandId, RuntimeBrandDefinition>;

export const RUNTIME_BRAND_IDS = Object.keys(RUNTIME_BRANDS) as RuntimeBrandId[];
